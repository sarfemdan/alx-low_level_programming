#include <stdio.h>

/**
  * reset_to_98 - update the value of n
  *
  * @n: value to be updated
  *
  * Return: no return value
  */
void reset_to_98(int *n)
{
	*n = 98;
}
