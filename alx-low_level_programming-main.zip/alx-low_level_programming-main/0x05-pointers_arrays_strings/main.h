#ifndef _main_h_
#define _main_h_

 void reset_to_98(int *n);
 void swap_int(int *a, int *b);
 int _strlen(char *s);
 int _putchar(char);
 void _puts(char *str);

#endif
