#ifndef _main_h_
#define _main_h_

 char *_strcat(char *dest, char *src);
 char *_strncat(char *dest, char *src, int n);
 char *cap_string(char *);

#endif
