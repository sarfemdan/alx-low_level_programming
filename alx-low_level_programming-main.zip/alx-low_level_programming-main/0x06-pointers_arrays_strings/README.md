# 0x06-pointers_arrays_strings
