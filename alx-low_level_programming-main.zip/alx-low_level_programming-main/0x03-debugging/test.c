#include <stdio.h>

int some_function(void)
{
    int i;

    for (i = 0; i < 10; i++)
    {
        printf("%d", i);
    }
    return(i);
}

int main(void)
{
	some_function();
	return (0);
}
