#ifndef _3_function_like_macro_h
#define _3_function_like_macro_h

#define ABS(x) (((x) < (0)) ? ((x) * (-1)) : (x))

#endif
