#ifndef _0_object_like_macro_h_
#define _0_object_like_macro_h_

#define SIZE 1024

#endif
