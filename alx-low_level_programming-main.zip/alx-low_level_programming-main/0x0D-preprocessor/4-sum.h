#ifndef _4_sum_h
#define _4_sum_h

#define SUM(x, y) ((x) + (y))

#endif
