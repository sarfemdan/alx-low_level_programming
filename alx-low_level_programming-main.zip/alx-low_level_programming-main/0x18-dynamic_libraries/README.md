# 0x18-dynamic_libraries
