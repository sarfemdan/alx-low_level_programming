#include "main.h"

/**
 * add - computes the addition of two integers
 *
 * @a: first number
 * @b: second number
 *
 * Return: the sum of a and b
 */
int add(int a, int b)
{
	return (a + b);
}
