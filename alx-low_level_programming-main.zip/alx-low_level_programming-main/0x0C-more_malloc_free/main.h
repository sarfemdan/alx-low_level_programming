#ifndef _main_h_
#define _main_h_

void *malloc_checked(unsigned int b);

#endif
