#ifndef _main_h_
#define _main_h_

char *create_array(unsigned int size, char c);

#endif
